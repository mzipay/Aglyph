from aglyph.assembler import Assembler
from movies import MoviesContext

assembler = Assembler(MoviesContext())
app = assembler.assemble("movies.lister.MovieLister")
for movie in app.movies_directed_by("Sergio Leone"):
    print(movie.title)


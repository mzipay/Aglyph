from movies.lister import MovieLister

app = MovieLister()
for movie in app.movies_directed_by("Sergio Leone"):
    print(movie.title)


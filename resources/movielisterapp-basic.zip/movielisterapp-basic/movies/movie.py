class Movie:

    def __init__(self, title, director):
        self.title = title
        self.director = director

